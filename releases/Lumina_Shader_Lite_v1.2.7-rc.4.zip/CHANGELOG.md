# Changelog

## 🧪 Lumina Shader Lite v1.2.7-rc.4 — 2026-08-27

Final optimization release candidate, making Low the factory-default profile and removing the inherited Complementary profile entry.

### ⚡ Optimized

- 🚀 Changed the shader's factory defaults to match the Low profile, including its lightweight material, shadow, antialiasing, and post-processing paths.

### 🎨 Interface

- 🧹 Removed the inherited Complementary profile from the profile selector so new installations identify Low as the active default.

### ✅ Validation

- 🧪 Updated release metadata and default-profile validation to use the new Low baseline.

## 🧪 Lumina Shader Lite v1.2.7-rc.3 — 2026-08-27

Hotfix release candidate restoring Potato, Very Low, and Low profile compatibility after the RC2 water optimization.

### 🛠️ Fixed

- 🌊 Restored low-detail water shader compilation by keeping the optional small-wave normal available to later lighting calculations without restoring its texture lookup.

## 🧪 Lumina Shader Lite v1.2.7-rc.2 — 2026-08-27

Second release candidate for v1.2.7, introducing the first real-optimization pass for low-end hardware and integrated graphics.

### ⚡ Optimized

- 🎚️ Rebalanced every performance profile into a consistent quality ladder, with expensive shadows, reflections, SSAO, and shader clouds removed from Potato.
- 🪞 Skipped the full-screen reflection pass when advanced block and world-space reflections are inactive.
- 🎬 Skipped the temporal antialiasing pass on minimum detail quality, where TAA is not compiled.
- ✨ Reduced low-detail bloom filtering from 49 to 25 samples per active tile.
- 🌊 Reduced low-detail procedural water normals from four texture reads to two.

### ✅ Validation

- 🧪 Added automatic checks for ordered performance profiles, Potato safeguards, and required Lite program fast paths.

## 🧪 Lumina Shader Lite v1.2.7-rc.1 — 2026-08-27

First release candidate for v1.2.7, focused on shader stability, cleaner Lite controls, stronger configuration validation, and a configurable procedural moon halo.

### ✨ Added

- 🌕 Added an optional procedural moon halo with a configurable intensity control and support in eligible sky reflections.

### 🛠️ Fixed

- 🎛️ Removed obsolete Advanced Color Tracing and World-Space Reflections controls from Lite profiles and the optimization menu.
- 🧹 Removed the orphaned Advanced Color Tracing settings-screen definition.
- 🧭 Protected custom labPBR normal-map reconstruction from negative square-root inputs caused by floating-point precision.
- 🧱 Initialized POM depth before every parallax path to prevent undefined custom-PBR displacement and slope normals.
- 🌈 Protected pixelated rainbows from horizon-aligned division by zero.
- ✨ Stabilized GGX highlights at degenerate half vectors and extreme reflection angles.
- ☁️ Clamped cloud-shadow angles before inverse trigonometric projection.
- 🔎 Added safe fallbacks for degenerate UV derivatives and transparent samples in anisotropic filtering.

### ✅ Validation

- 🧪 Added automatic checks for obsolete profile controls, missing menu options, orphaned screens, and duplicate or invalid sliders.

## 🌌 Lumina Shader Lite v1.2.6 — 2026-08-01

This maintenance update makes Lumina Shader Lite more stable in difficult rendering conditions while preserving its lightweight design and visual identity. ✨

### 🛠️ Fixed — Rendering Stability

- 🛡️ Prevented black rectangles around enchanted armor and players by safely discarding near-transparent fragments.
- 🌤️ Prevented invalid `NaN` values in natural and ice light shafts when shadow colors have no length.
- ☁️ Stabilized cloud-shadow projection when the sun aligns with a horizontal world axis.
- ❄️ Protected biome-tint removal from division by zero on snowy terrain, leaves, and IPBR materials.
- 💧 Prevented high water-wave settings from producing invalid normal-map calculations.
- 🌫️ Protected Lightshaft Smoke from division by zero in empty volumetric samples.

### 🎨 Improved — Compatibility & Interface

- 👻 Preserved intentionally translucent modded entities while still discarding fully transparent fragments.
- 🎛️ Removed unavailable Advanced Color Tracing controls from the Lite interface and profiles.

### ✅ Validation

- 🔍 Version checks now require exact metadata matches and reject incorrect pre-release suffixes.
- 🤖 Added automatic shader validation for development pushes, `main`, and pull requests.
- 📦 Verified shader includes, preprocessor blocks, default profiles, metadata, and ZIP/source parity.
- 🧹 Confirmed that the final ZIP contains 397 files with no unnecessary macOS metadata.

💙 Thank you for using Lumina Shader Lite! Enjoy a cleaner, safer, and more stable visual experience.

## 1.2.5 - 2026-07-25

Stable release focused on sky customization, clearer distant atmosphere, safer emissive lighting, and inherited weather-color corrections.

### Added

- Added a Milky Way Brightness control under Environment & Sky with OFF, 25%, 50%, 75%, 100%, 125%, and 150% levels.
- Disabling the Milky Way now removes its procedural calculation from the compiled sky and reflection shaders.

### Changed

- Added an independent Lava Brightness slider under IntegratedPBR+ glowing-material settings.

### Fixed

- Limited lava emission and bloom input so large lava surfaces no longer overexpose the image to white.
- Corrected the middle-sky color used by the Heavy & Colder rainy-weather style.

## 1.2.5-pre.1 - 2026-07-19

Pre-release candidate for in-game validation before the stable v1.2.5 release.

### Changed

- Shifted the clear daytime horizon and distant atmospheric fog from pale white toward a cleaner sky blue.

### Fixed

- Removed the spherical coordinate seam from the Milky Way cloud pattern.
- Attached the galactic plane to the moving celestial basis so it follows the night sky.

### Optimized

- Reduced Milky Way value-noise hashing from eight trigonometric hashes per sky pixel to four.

## 1.2.4 - 2026-07-17

Stable release based on the fourth in-game test candidate. It combines internal stability and performance work with a new lightweight Milky Way effect.

### Added

- Added a wide diagonal Milky Way arc with rounded galactic clouds, a warm core, cool outer haze, and a warped central dust lane.

### Fixed

- Prevented zero-luminance color normalization from generating invalid `NaN` values.
- Corrected temporal reprojection for Distant Horizons LOD geometry to reduce ghosting during camera movement.
- Removed directional streaks from the Milky Way while preserving the dark midnight background and existing stars.

### Optimized

- Reused squared lightmap values during shadow sampling to avoid redundant per-fragment calculations.
- Built the Milky Way without texture samples, new assets, or volumetric ray marching.

### Validation

- Added automated checks for JSON metadata, shader includes, preprocessor balance, default profile mapping, and ZIP/source parity.

## 1.2.4-rc.3 - 2026-07-17

Third in-game test candidate. This is not yet the stable v1.2.4 release.

### Changed

- Reworked the Milky Way into a wider and substantially more visible galactic arc.
- Added irregular luminous clouds, a warm galactic core, fine structure, and a warped central dust lane inspired by real night-sky photography.

### Performance

- Reuses the shader pack's existing noise texture with three samples and no iterative noise loops or volumetric ray marching.

## 1.2.4-rc.2 - 2026-07-17

Second in-game test candidate. This is not yet the stable v1.2.4 release.

### Added

- Added a subtle, tilted Milky Way band at night while preserving the existing dark midnight sky and stars.
- Added a lightweight central dust lane and gentle brightness variation to give the band natural structure.

### Performance

- The Milky Way uses an analytic shader calculation with no additional texture samples, loops, or volumetric noise.
- Added the same subtle band to eligible high-quality sky reflections for visual consistency.

## 1.2.4-rc.1 - 2026-07-17

Pre-release candidate for in-game validation. This is not yet the stable v1.2.4 release.

### Fixed

- Prevented zero-luminance color normalization from generating invalid `NaN` values.
- Corrected temporal reprojection for Distant Horizons LOD geometry to reduce ghosting during camera movement.

### Optimized

- Reused squared lightmap values during shadow sampling to avoid redundant per-fragment calculations.

### Validation

- Added automated checks for JSON metadata, shader includes, preprocessor balance, default profile mapping, and ZIP/source parity.

## 1.2.3 - 2026-07-13

Lumina Shader Lite 1.2.3 is a maintenance release focused exclusively on bug fixes. It does not introduce intentional visual changes or new features.

### Fixed

- Corrected vertical image-sharpening offsets on non-square resolutions.
- Replaced undefined reversed `smoothstep` calls in dark-color tonemapping.
- Corrected the Distant Horizons water fade to behave consistently across GPU drivers.
- Removed invalid GLSL text from the reserved `composite2` program.
- Centered the final dithering noise to prevent a small positive brightness bias.
- Added the missing default profile mapping so the active defaults are identified correctly.
- Removed the incorrect "Default" label from the High profile.
